#!/bin/bash

###############################################################################
## Get arguments
###############################################################################
if [ -z "$1" ] ; then
	echo "No argument supplied: Please specify simulation directory name."
	echo "Usage: <script> <dir_name>"
	exit 1
fi

###############################################################################
## Prepare tools
###############################################################################

if ! java -version > /dev/null  2>&1; then 
	echo "No java version installed. Please install at least version 7."
	echo "Installing: sudo apt-get install default-jre"
	exit 1
fi

if ! python -c "import matplotlib"; then
	echo "Python matplotlib not installed."
	echo "Installing: python -m pip install matplotlib."
	exit 1
fi


if ! python -c "import numpy"; then
	echo "Python numpy not installed."
	echo "Installing: python -m pip install numpy."
	exit 1
fi

###############################################################################
## Downloading files
###############################################################################
if [ -d ./install ] ; then
	echo "Installation directory already exists. Try downloading files."
else
	echo "Installation directory does not exist. Creating installation directory."
	mkdir install
fi

if [ -f ./install/VMSimInt-20160622.tar.gz ]
then
        echo "ikr-VMSimInt was found. No download required."
else
        echo "ikr-VMSimInt was not found. Downloading the package."
        wget -O ./install/VMSimInt-20160622.tar.gz http://www.ikr.uni-stuttgart.de/IKRSimLib/files/VMSimInt-20160622.tar.gz
fi

if [ -d ./install/VMSimInt-20160622 ] ; then
	echo "Extracted files already exists."
else
	echo "Unpacking the tar file."
	tar -xzvf ./install/VMSimInt-20160622.tar.gz -C ./install/
fi


if [ -f ./install/ikr-simlib-4.0.0-lib.tar.gz ] ; then
        echo "ikr-simlib was found. No download required."
else
        echo "ikr-simlib was not found. Downloading ikr-simlib"
        wget -O ./install/ikr-simlib-4.0.0-lib.tar.gz http://www.ikr.uni-stuttgart.de/IKRSimLib/files/ikr-simlib-4.0.0-lib.tar.gz
        tar -xzvf ikr-simlib-4.0.0-lib.tar.gz -C ./install
fi

if [ -d ./install/ikr-simlib-4.0.0-lib ] ; then
	echo "Extracted files already exists."
else
	echo "Unpacking the tar file."
	mkdir ./install/ikr-simlib-4.0.0-lib
	tar -xzvf ./install/ikr-simlib-4.0.0-lib.tar.gz -C ./install/ikr-simlib-4.0.0-lib
fi


###############################################################################
## Prepare simulation directory
###############################################################################

if [ -d  ./$1 ] ; then
	echo "Simulation directory already exists."
else
	echo "Creating simulation directoy."
	mkdir ./$1
fi

if [ -d  ./$1/jars ] ; then
	echo "Jar directory already exists."
else
	echo "Creating jar directoy."
	mkdir ./$1/jars
fi

echo "Extracting files into simulation directory"
for t in ./install/VMSimInt-20160622/*.tar.gz; do tar xzf $t -C ./$1; done
echo "Moving all jar files into jar directory"
mv ./$1/*.jar ./$1/jars
echo "Copying simlib into jar directory"
cp ./install/ikr-simlib-4.0.0-lib/ikr-simlib-4.0.0.jar ./$1/jars

###############################################################################
## Prepare simulation run script
###############################################################################

echo "Creating run.sh script."
cat << EOT > ./$1/run.sh
#!/bin/sh

rm -f *.csv *.pcap *std*

echo "Simulating...this may take a while."
java -cp "jars/*" ikr.qemu.example.models.DumbbellModel -c simple 2> execution.log && echo "Finished simulation. See execution.log for output infos." || echo "Simulation error. See execution.log for infos"

rm -f *std* COPYING README

sed -i 's/,/./g' *csv 2> /dev/null
sed -i 's/,/./g' *InRates 2> /dev/null
sed -i 's/,/./g' *OutRates 2> /dev/null
EOT

echo "#Following parameters are from the tutorial Problem 1" >> ./$1/sim.par
echo "#MinimalDumbbell.DefaultCongestionControl = reno" >> ./$1/sim.par
echo "#MinimalDumbbell.CentralLinkClientToServer.QueuingEntity.QueuingDiscipline = ikr.protocolsupport.algorithms.queuingDisciplines.TracingBoundedFIFOQDisc" >> ./$1/sim.par
echo "#MinimalDumbbell.CentralLinkClientToServer.QueuingEntity.QueuingDiscipline.TraceFile = queue.csv" >> ./$1/sim.par
echo "#MinimalDumbbell.L4Connection*.LoggedTcpInfoValues = snd_cwnd;snd_ssthresh;rtt;rttvar" >> ./$1/sim.par

chmod +x ./$1/run.sh


###############################################################################
## Prepare clean script
###############################################################################
echo "Creating clean.sh script"
cat << EOT > ./$1/clean.sh
#!/bin/sh
rm -f *.pcap *.csv *.log *std* *InRates *OutRates
EOT

chmod +x ./$1/clean.sh

###############################################################################
## Prepare simulation view script (python)
###############################################################################

echo "Creating plot.py script"
cat << EOT > ./$1/plot.py
import sys
import csv
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import os.path


def is_number(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

def check_args(argv):
	scale = False
	ylim = None
	files = []
	for item in argv:
		if item == "scale":
			scale = True
			continue
		if is_number(item):
			ylim = int(item)
		elif os.path.isfile(item):
			files.append(item)
		else:
			print(item, "is not a valid file")
	return files, ylim, scale		

def main():
	# get commandline arguments
	argv = sys.argv

	# check if arguments are given
	if len(argv) < 2:
		print("Usage: <script> [options] [FILE ...]")
		print("Options could be a number for ylim and \"scale\" to scale the rtt")
		print("Example: python plot.py data.csv 1000 scale")
		sys.exit(1)

	# get all filearguments and ylim for plotting
	file_list, ylim, scale = check_args(argv[1:])

	if len(file_list) < 1:
		print("No valid arguments were given..")
		sys.exit(2)

	# register csv parser
	csv.register_dialect('semicolon', delimiter=';', skipinitialspace=True)


	#create graph to plot
	fig = plt.figure()
	graph = fig.add_subplot(111)
	graph.grid()
	graph.set_title("")
	graph.set_xlabel('time [secs]')
	if ylim is not None:
		graph.set_ylim([0,ylim])


	# parse all csv files
	for file in file_list:
		table = []
		with open(file,'rb') as csvfile:
			reader = csv.reader(csvfile, dialect = csv.get_dialect('semicolon'))
			#read first line
			line = reader.next()
			
			#while we have fewer than 2 columns read next line
			while len(line) < 2:
				line = reader.next()
			
			# read header
			header = line
			
			# while line starts with # -> skip this line and save it as header
			while '#' in line[0]:
				line = reader.next()

			# parse all items in line
			for item in line:
				table.append([])

			# parse row for row and save the data
			for row in reader:
				for col, data in enumerate(row):
					if scale:
						if col == 3:
							data = int(data)/1000
					table[col].append(data)

			for col in range(1, len(table)) :
				graph.plot(table[0], table[col], label=header[col])

	# plot
	graph.legend()
	plt.show()

# execute main
main()
EOT

chmod +x ./$1/plot.py

###############################################################################
## Done
###############################################################################
echo "----------------Creation done----------------------"
echo "Change to the folder and run run.sh to simulate."
echo "After the simulation run plot.py (python plot.py <file>) to see the results."
echo "For more data uncomment the last lines in sim.par."

